import React from "react";
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home/Home";
import About from "./components/About/About"
import Contact from "./components/Contact/Contact"
import RumourDetection from "./components/RumourDetection/RumourDetection"

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/rumour-detection" element={<RumourDetection />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;



 // import React, {useState, useEffect } from 'react'

// const App = () => {
//   const [data, setData] = useState([{}])

//   useEffect(() => {
//     fetch("/image_detection").then(
//       res => res.json()
//     ).then(
//       data => {
//         setData(data)
//         console.log(data);
//       }
//     )
//   }, [])
//   return (
//     <div>
      
//     </div>
//   )
// }

// export default App


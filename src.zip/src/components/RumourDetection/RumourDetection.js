import React, { useState } from "react";
import './RumourDetection.css'

function RumourDetection() {
  const [news, setNews] = useState("");
  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    setNews(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/check_news", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ news }),
      });
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div className="rumour-detection-container">
      <h1 className="rumour-detection-heading">Hey there, Welcome to our page. You can drop your news down in the text box and we will try our level best to help you.</h1>
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8_G62rTtANDkQzjyjPkUxJ-OuGnGnIzw086_aPnNtkw&s"/>
      <br/>
      <form className="rumour-detection-form" onSubmit={handleSubmit}>
        <div className="form-group">
        <br/>
          <label htmlFor="newsInput" className="form-label">Enter News Article:</label>
          <input
            type="text"
            className="form-control"
            id="newsInput"
            value={news}
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Check Rumours
        </button>
      </form>
      {result && (
        <div className="result-container">
          <h3 className="result-heading">Result:</h3>
          <p className="result-text">{result.result}</p>
          {result.text && (
            <div className="result-details">
              <p><strong>Text:</strong> {result.text}</p>
              <p><strong>Date:</strong> {result.date}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default RumourDetection;

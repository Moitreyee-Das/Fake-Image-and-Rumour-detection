import React from 'react'
import './About.css';

const About = () => {
  return (
    <div>
         <nav className="navbar navbar-expand-lg p-3 mb-4 bg-dark text-decoration-none">
    <div className="container-fluid">
        <a className="navbar-brand" href="/">
        <img src='C:\Users\KIIT\Desktop\Main-Projects\FakeNews\client\Images\Images\logo-black.png'/>
        </a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
            <a className="nav-link text-white text-decoration-none" aria-current="page" href="/">Home</a>
            </li>
            <li className="nav-item">
            <a className="nav-link active text-white text-decoration-none" href="/about">About Us</a>
            </li>
            <li className="nav-item">
            <a className="nav-link text-white text-decoration-none" href="/contact">Contact Us</a>
            </li>
            
            </ul>
        </div>
    </div>
</nav>

        <div>
            <div className="about-section">
                <h1>About Us Page</h1>
                <p><b><i>Welcome to our website! We are a team of passionate individuals dedicated to providing quality products/service.</i></b></p>
                <h1>Mission</h1>
                <p> Amidst the chaos of rampant image forgery and the proliferation of fake news across the internet, it has become increasingly difficult for users to discern truth from falsehood. In a world where trust is often placed in what is seen, the dissemination of rumors and misinformation has reached unprecedented levels.
                Our mission is to provide users with the tools and resources they need to detect fake news, misleading links, and manipulated images. Through this project, we aim to empower users to navigate the digital landscape with confidence, enabling them to make informed decisions and avoid falling prey to the tactics of unethical individuals who seek to deceive and manipulate for their own gain.
                We believe that by arming users with the knowledge and skills to identify and combat misinformation, we can help mitigate the spread of false narratives and uphold the integrity of information on the internet.</p>
            </div>
            <br /><br />

            <div className="team-heading">Introducing you to the Team</div>
            <span>(The 3 Geniuses)</span>
            <br /><br />

            <div className="row">
                <div className="column">
                    <div className="card">
                        <img src="https://i.pinimg.com/736x/35/b2/7e/35b27eda67f73e30f3c3ae1618af9fda.jpg" alt="Moitreyee Das" style={{ height: '450px' }} />
                        <div className="about-container">
                            <h2>MOITREYEE DAS</h2>
                            <p className="title">Backend and Frontend Developer</p>
                            <p>A student frontend and backend developer is a coding apprentice, building websites by day, slaying pixels by night (figuratively). They're learning both sides (front-end and back-end) to become full-fledged web developers.</p>
                        </div>
                    </div>
                </div>

                <div className="column">
                    <div className="card">
                        <img src="https://i.pinimg.com/originals/69/90/27/69902725ada21606958f5a014b7067bf.jpg" alt="Shreyasee Sarkar" style={{ height: '450px' }} />
                        <div className="about-container">
                            <h2>SHREYASEE SARKAR</h2>
                            <p className="title">Backend and Frontend Developer</p>
                            <p>A student frontend and backend developer is a web development apprentice, learning to build both the user-facing side (frontend) and the internal logic (backend) of websites and apps. They're armed with basic coding skills and eager to grow!</p>
                        </div>
                    </div>
                </div>

                <div className="column">
                    <div className="card">
                        <img src="https://cdn.firstcuriosity.com/wp-content/uploads/2023/07/26102225/Q_1690346929.jpg" alt="Ahona Roychoudhary" style={{ height: '450px' }} />
                        <div className="about-container">
                            <h2>AHONA ROYCHOUDHURY</h2>
                            <p className="title">frontend developer</p>
                            <p>A student frontend developer is a web apprentice, crafting the visual and interactive elements of websites - the user experience architects of the web. They're learning the building blocks (HTML, CSS, JavaScript) and making things user-friendly.</p>
                        </div>
                    </div>
                </div>
            </div>

            <footer className>
                <div>
                    <div className="footer-content text-center">
                        <p className="fs-15"> &copy; Copyright 2024. All right Reserved - <span>Mirage</span></p>
                    </div>
                </div>
            </footer>
        </div>
        </div>
    );
}

export default About;


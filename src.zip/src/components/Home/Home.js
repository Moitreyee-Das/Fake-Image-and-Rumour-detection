import './styles.css';
import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <>
      
      <nav className="navbar navbar-expand-lg p-3 mb-4 bg-dark text-white">
  <div className="container-fluid">
      <a className="navbar-brand" href="/">Mirage</a>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
          <li className="nav-item">
          <a className="nav-link active text-white text-decoration-none" aria-current="page" href="/">Home</a>
          </li>
          <li className="nav-item">
          <a className="nav-link text-white text-decoration-none" href="/about">About Us</a>
          </li>
          <li className="nav-item">
          <a className="nav-link text-white text-decoration-none" href="/contact">Contact Us</a>
          </li>
          
          </ul>
      </div>
  </div>
</nav>

  <header className="header bg-bright" id="header">
      
        <div className="header-content text-center">
          <h2 className="header-text"><b>IMAGE FORGERY AND RUMOUR DETECTION</b></h2><br />
          <h1 className="lg-title-1">See the Truth. Get the Facts. Faster. Stop wasting time deciphering online fiction. MIRAGE empowers you to instantly identify image manipulation and debunk rumours with ease. Our Motto is to provide assistance to the people who are in a dilemma to whether trust the news they see or not. Our Website will help them to differentiate between real and fake.</h1><br /><br /><hr/>
          <p className="header-title">Online Chaos? Find Clarity. Unmask fake images & debunk rumors in minutes. MIRAGE - Your truth shield in the digital age. Start seeing facts, not fiction.</p>
        </div>
    </header>
    <br/>
    <br/>

    <div className="section-two bg-bright">
      <div className="section-two-content">
        <div className="section-items">
          <div className="section-item">
            <div className="section-item-icon">
              <img src="https://previews.123rf.com/images/vectorlab/vectorlab2003/vectorlab200300507/141714152-social-media-forgery-information-concept-male-character-with-huge-magnifying-glass-looking-on-fake.jpg" height="100px" width="100px"/>
            </div>
            <br/>
            <h5 className="section-item-title">The web is full of phoney baloney. We separate the real from the bologna.</h5>
            <p className="text">In the vast expanse of the internet, distinguishing between genuine information and deceptive content can be challenging. However, with critical thinking and fact-checking, we can sift through the phoney baloney to uncover the truth. It's essential to be vigilant and discerning to navigate this digital landscape successfully.</p>
          </div>

          <div className="section-item">
            <div className="section-item-icon">
              <img src="https://png.pngtree.com/png-clipart/20210128/ourmid/pngtree-deceive-the-elderly-to-prevent-fraud-png-image_2825995.jpg"/>
            </div>
            <br/>
            <h5 className="section-item-title">Seeing is deceiving. We help you believe.</h5>
            <p className="text">The world throws illusions your way, but don't be fooled by what appears at face value. We can help you sift through the deception and uncover the truth you can truly believe in.</p>
          </div>

          <div className="section-item">
            <div className="section-item-icon">
              <img src="https://www.shutterstock.com/image-vector/photo-camera-doodle-icon-hand-600nw-1499763380.jpg" />
            </div>
            <br/>
            <h5 className="section-item-title">Turning Photoshop fantasies into real facts.</h5>
            <p className="text">Don't believe everything you see online. With a few clicks, photos can be manipulated to create a completely unreal scenario. Developing a healthy skepticism is key to spotting these fabricated "facts" and uncovering the truth.</p>
          </div>
        </div>
      </div>
    </div>
    <hr/>
    <div className="section-one">
      <div className="container">
        <div className="section-one-content">
          <div className="section-one-r text-center">
            <h2 className="lg-title"> Use the best Image detector as your Fact-checker</h2>
            <p className="text">Image forgery detection is the process of identifying alterations or tampering in digital images to ensure their authenticity. It's crucial for maintaining trust in journalism, forensic investigations, and legal proceedings. By detecting forged images, it helps prevent the spread of misinformation, combat fraud, and uphold integrity in visual data. Techniques involve analyzing pixel-level inconsistencies, metadata anomalies, and employing machine learning algorithms to identify manipulation patterns. Overall, image forgery detection safeguards against deceptive practices, ensuring the reliability and credibility of digital imagery across various domains.</p>
            <div className="section-one-l">
            <img src="https://images.wsj.net/im-436082?width=700&height=466" width="100%" height="400px" />
          </div>
            <div className="button">
            {/* <Link to="/detect-forgery">
              <button>Image Forgery Detection</button>
            </Link> */}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className="section-one">
      <div className="container">
        <div className="section-one-content">
          <div className="section-one-r text-center">
            <h2 className="lg-title"> Use the best Rumour detector as your Fact-checker</h2>
            <p className="text">Rumor detection involves identifying and debunking false or misleading information circulating online. It's essential due to the prevalence of misinformation, fake news, and propaganda on digital platforms. By analyzing social media data, textual content, and network dynamics, rumor detection systems help prevent the spread of deceptive information and maintain the credibility of online platforms. Detecting rumors is crucial for preserving public trust, promoting informed decision-making, and safeguarding against the negative impacts of misinformation, such as societal discord, political polarization, and public health risks. Overall, rumor detection contributes to fostering a more reliable and trustworthy online environment.</p>
            <div className="section-one-l">
            <img src="https://png.pngtree.com/png-clipart/20230923/original/pngtree-woman-under-influence-of-fake-news-mind-manipulation-female-vector-png-image_12666794.png" />
          </div>
            <div className="button">
            <Link to="/rumour-detection">
              <button>Check Rumours</button>
            </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
    <hr/>
    <footer>
      <div>
        <div className="footer-content text-center">
          <p> Copyright 2024. All right Reserved - <span>Mirage</span></p>
        </div>
      </div>
    </footer>
  
  </> 
  )
}

export default Home

import React from 'react'
import './Contact.css';

const Contact = () => {
  return (
    <div>
        <nav className="navbar navbar-expand-lg p-3 mb-4 bg-dark text-white">
    <div className="container-fluid">
        <a className="navbar-brand" href="/">Navbar</a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
            <a className="nav-link text-white text-decoration-none" aria-current="page" href="/">Home</a>
            </li>
            <li className="nav-item">
            <a className="nav-link text-white text-decoration-none" href="/about">About Us</a>
            </li>
            <li className="nav-item">
            <a className="nav-link active text-white text-decoration-none" href="/contact">Contact Us</a>
            </li>
            
            </ul>
        </div>
    </div>
</nav>
  <div class="container">
    <h1><u>Contact Us</u></h1>
    <form action="#" method="post">
      <div class="form-group">
        <label htmlFor="name">
            Name:
            </label>
        <input type="text" id="name" name="name" required/>
      </div>
      <div class="form-group">
        <label for="phone">Contact Number:</label>
        <input type="tel" id="phone" name="phone" required/>
      </div>
      <div class="form-group">
        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required/>
      </div>
      <div class="form group">
      <label for="Message">Message:</label>
      <input type="textid" id="Message"   name="Message" required/>
      <br/>
      <div class="form-group">
        <button type="submit">Submit</button>
        <div class="phone-numbers">
            <p><u><b>Phone Numbers:</b></u></p>
            <ul>
              {/* <li></li> */}
              <li>SHREYASEE SARKAR: +91-6200256509</li>
              <li>MOITREYEE DAS: +91-907323948</li>
              <li>AHONA ROYCHOUDHURY: +91-9007211026</li>
            </ul>
          </div>
     </div>
     </div>
    </form>
  </div>

  <footer>
  <p>&copy; 2024 Contact Us. All rights reserved<span>-Mirage</span></p>
</footer>
      
    </div>
  )
}

export default Contact
